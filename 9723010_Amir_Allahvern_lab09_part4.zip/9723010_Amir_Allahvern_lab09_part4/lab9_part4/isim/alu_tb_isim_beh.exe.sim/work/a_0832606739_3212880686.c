/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/lessons/term4/memari/modelsim/azmaysh5555/lab9_part4/alu.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);


static void work_a_0832606739_3212880686_p_0(char *t0)
{
    char t26[16];
    char t42[16];
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    int t22;
    char *t23;
    int t25;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned char t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t43;

LAB0:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 1472U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4432);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(69, ng0);
    t4 = (t0 + 1352U);
    t8 = *((char **)t4);
    t4 = (t0 + 7651);
    t10 = xsi_mem_cmp(t4, t8, 3U);
    if (t10 == 1)
        goto LAB9;

LAB16:    t11 = (t0 + 7654);
    t13 = xsi_mem_cmp(t11, t8, 3U);
    if (t13 == 1)
        goto LAB10;

LAB17:    t14 = (t0 + 7657);
    t16 = xsi_mem_cmp(t14, t8, 3U);
    if (t16 == 1)
        goto LAB11;

LAB18:    t17 = (t0 + 7660);
    t19 = xsi_mem_cmp(t17, t8, 3U);
    if (t19 == 1)
        goto LAB12;

LAB19:    t20 = (t0 + 7663);
    t22 = xsi_mem_cmp(t20, t8, 3U);
    if (t22 == 1)
        goto LAB13;

LAB20:    t23 = (t0 + 7666);
    t25 = xsi_mem_cmp(t23, t8, 3U);
    if (t25 == 1)
        goto LAB14;

LAB21:
LAB15:    xsi_set_current_line(89, ng0);

LAB8:    goto LAB3;

LAB5:    t4 = (t0 + 1512U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB9:    xsi_set_current_line(71, ng0);
    t27 = (t0 + 1032U);
    t28 = *((char **)t27);
    t27 = (t0 + 7468U);
    t29 = (t0 + 1192U);
    t30 = *((char **)t29);
    t29 = (t0 + 7484U);
    t31 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t26, t28, t27, t30, t29);
    t32 = (t26 + 12U);
    t33 = *((unsigned int *)t32);
    t34 = (1U * t33);
    t35 = (8U != t34);
    if (t35 == 1)
        goto LAB23;

LAB24:    t36 = (t0 + 4512);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    memcpy(t40, t31, 8U);
    xsi_driver_first_trans_fast_port(t36);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 4576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB10:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t2 = (t0 + 4512);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t4, 8U);
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 4576);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = t1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB11:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 7468U);
    t5 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t26, t4, t2);
    t8 = (t26 + 12U);
    t33 = *((unsigned int *)t8);
    t34 = (1U * t33);
    t1 = (8U != t34);
    if (t1 == 1)
        goto LAB25;

LAB26:    t9 = (t0 + 4512);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t5, 8U);
    xsi_driver_first_trans_fast_port(t9);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 4576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB12:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t33 = (7 - 7);
    t34 = (t33 * 1U);
    t41 = (0 + t34);
    t2 = (t4 + t41);
    t8 = ((IEEE_P_2592010699) + 4024);
    t9 = (t42 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 7;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t10 = (1 - 7);
    t43 = (t10 * -1);
    t43 = (t43 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t43;
    t5 = xsi_base_array_concat(t5, t26, t8, (char)99, (unsigned char)2, (char)97, t2, t42, (char)101);
    t43 = (1U + 7U);
    t1 = (8U != t43);
    if (t1 == 1)
        goto LAB27;

LAB28:    t11 = (t0 + 4512);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t5, 8U);
    xsi_driver_first_trans_fast_port(t11);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 4576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB13:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t2 = (t0 + 4512);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t4, 8U);
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 4576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB14:    xsi_set_current_line(86, ng0);
    t2 = (t0 + 2792U);
    t4 = *((char **)t2);
    t2 = (t0 + 2632U);
    t5 = *((char **)t2);
    t8 = ((IEEE_P_2592010699) + 4024);
    t9 = (t0 + 7580U);
    t11 = (t0 + 7564U);
    t2 = xsi_base_array_concat(t2, t26, t8, (char)97, t4, t9, (char)97, t5, t11, (char)101);
    t33 = (4U + 4U);
    t1 = (8U != t33);
    if (t1 == 1)
        goto LAB29;

LAB30:    t12 = (t0 + 4512);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t2, 8U);
    xsi_driver_first_trans_fast_port(t12);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 4576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB22:;
LAB23:    xsi_size_not_matching(8U, t34, 0);
    goto LAB24;

LAB25:    xsi_size_not_matching(8U, t34, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(8U, t43, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(8U, t33, 0);
    goto LAB30;

}


extern void work_a_0832606739_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0832606739_3212880686_p_0};
	xsi_register_didat("work_a_0832606739_3212880686", "isim/alu_tb_isim_beh.exe.sim/work/a_0832606739_3212880686.didat");
	xsi_register_executes(pe);
}
