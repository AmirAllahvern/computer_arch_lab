/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/lessons/term4/memari/modelsim/azmaysh5555/azmaysh8/tb_divider.vhd";



static void work_a_2683472623_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    int64 t10;
    char *t11;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    int64 t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    int64 t26;
    char *t27;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    t1 = (t0 + 2832U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(82, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 5421);
    t5 = (t0 + 3216);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, t3);
    t10 = (200 * 1000LL);
    t11 = (t0 + 5429);
    t13 = (t0 + 3216);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 8U);
    xsi_driver_subsequent_trans_delta(t13, 0U, 8U, t10);
    t18 = (300 * 1000LL);
    t19 = (t0 + 5437);
    t21 = (t0 + 3216);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 8U);
    xsi_driver_subsequent_trans_delta(t21, 0U, 8U, t18);
    t26 = (400 * 1000LL);
    t27 = (t0 + 5445);
    t29 = (t0 + 3216);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    memcpy(t33, t27, 8U);
    xsi_driver_subsequent_trans_delta(t29, 0U, 8U, t26);
    t34 = (t0 + 3216);
    xsi_driver_intertial_reject(t34, t3, t3);
    xsi_set_current_line(83, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 5453);
    t5 = (t0 + 3280);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_delta(t5, 0U, 4U, t3);
    t10 = (200 * 1000LL);
    t11 = (t0 + 5457);
    t13 = (t0 + 3280);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 4U);
    xsi_driver_subsequent_trans_delta(t13, 0U, 4U, t10);
    t18 = (300 * 1000LL);
    t19 = (t0 + 5461);
    t21 = (t0 + 3280);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 4U);
    xsi_driver_subsequent_trans_delta(t21, 0U, 4U, t18);
    t26 = (400 * 1000LL);
    t27 = (t0 + 5465);
    t29 = (t0 + 3280);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    memcpy(t33, t27, 4U);
    xsi_driver_subsequent_trans_delta(t29, 0U, 4U, t26);
    t34 = (t0 + 3280);
    xsi_driver_intertial_reject(t34, t3, t3);
    xsi_set_current_line(84, ng0);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

}


extern void work_a_2683472623_2372691052_init()
{
	static char *pe[] = {(void *)work_a_2683472623_2372691052_p_0};
	xsi_register_didat("work_a_2683472623_2372691052", "isim/tb_divider_isim_beh.exe.sim/work/a_2683472623_2372691052.didat");
	xsi_register_executes(pe);
}
