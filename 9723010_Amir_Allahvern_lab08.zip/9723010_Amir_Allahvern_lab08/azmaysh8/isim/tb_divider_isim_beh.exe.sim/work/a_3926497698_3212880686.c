/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/lessons/term4/memari/modelsim/azmaysh5555/azmaysh8/divider.vhd";
extern char *IEEE_P_3620187407;

unsigned char ieee_p_3620187407_sub_1742983514_3965413181(char *, char *, char *, char *, char *);
unsigned char ieee_p_3620187407_sub_4060537613_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_3926497698_3212880686_p_0(char *t0)
{
    char t19[16];
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t10;
    int t11;
    int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    int t17;
    unsigned char t18;
    char *t20;
    char *t21;
    char *t22;
    unsigned char t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 1968U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t1, 4U);
    xsi_set_current_line(31, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (7 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 2088U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t1, 4U);
    xsi_set_current_line(32, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t1 = (t0 + 6132U);
    t6 = (t0 + 1192U);
    t7 = *((char **)t6);
    t6 = (t0 + 6084U);
    t8 = ieee_p_3620187407_sub_4060537613_3965413181(IEEE_P_3620187407, t2, t1, t7, t6);
    if (t8 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t1 = (t0 + 6132U);
    t6 = (t0 + 1192U);
    t7 = *((char **)t6);
    t6 = (t0 + 6084U);
    t8 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t1, t7, t6);
    if (t8 != 0)
        goto LAB5;

LAB6:
LAB3:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2208U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t1 = (t0 + 3712);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t8;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t1 = (t0 + 3776);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(61, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t1 = (t0 + 3840);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 3632);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(33, ng0);
    t9 = (t0 + 2208U);
    t10 = *((char **)t9);
    t9 = (t10 + 0);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_set_current_line(34, ng0);
    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    memset(t2, (unsigned char)1, 4U);
    t6 = (t0 + 1968U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t1, 4U);
    xsi_set_current_line(35, ng0);
    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    memset(t2, (unsigned char)1, 4U);
    t6 = (t0 + 2088U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t1, 4U);
    goto LAB3;

LAB5:    xsi_set_current_line(37, ng0);
    t9 = (t0 + 2208U);
    t10 = *((char **)t9);
    t9 = (t10 + 0);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_set_current_line(38, ng0);
    t1 = (t0 + 6194);
    *((int *)t1) = 3;
    t2 = (t0 + 6198);
    *((int *)t2) = 0;
    t11 = 3;
    t12 = 0;

LAB7:    if (t11 >= t12)
        goto LAB8;

LAB10:    goto LAB3;

LAB8:    xsi_set_current_line(40, ng0);
    t6 = (t0 + 1968U);
    t7 = *((char **)t6);
    t13 = (3 - 3);
    t3 = (t13 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t6 = (t7 + t5);
    t8 = *((unsigned char *)t6);
    t9 = (t0 + 2328U);
    t10 = *((char **)t9);
    t9 = (t10 + 0);
    *((unsigned char *)t9) = t8;
    xsi_set_current_line(41, ng0);
    t1 = (t0 + 1968U);
    t2 = *((char **)t1);
    t3 = (3 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = xsi_get_transient_memory(3U);
    memcpy(t6, t1, 3U);
    t7 = (t0 + 1968U);
    t9 = *((char **)t7);
    t14 = (3 - 3);
    t15 = (t14 * 1U);
    t16 = (0 + t15);
    t7 = (t9 + t16);
    memcpy(t7, t6, 3U);
    xsi_set_current_line(42, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t13 = (3 - 3);
    t3 = (t13 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t8 = *((unsigned char *)t1);
    t6 = (t0 + 1968U);
    t7 = *((char **)t6);
    t17 = (0 - 3);
    t14 = (t17 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t6 = (t7 + t16);
    *((unsigned char *)t6) = t8;
    xsi_set_current_line(43, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t3 = (3 - 2);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = xsi_get_transient_memory(3U);
    memcpy(t6, t1, 3U);
    t7 = (t0 + 2088U);
    t9 = *((char **)t7);
    t14 = (3 - 3);
    t15 = (t14 * 1U);
    t16 = (0 + t15);
    t7 = (t9 + t16);
    memcpy(t7, t6, 3U);
    xsi_set_current_line(44, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t3 = (t13 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    *((unsigned char *)t1) = (unsigned char)2;
    xsi_set_current_line(48, ng0);
    t1 = (t0 + 2328U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t18 = (t8 == (unsigned char)3);
    if (t18 != 0)
        goto LAB11;

LAB13:    t1 = (t0 + 2328U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t18 = (t8 == (unsigned char)2);
    if (t18 != 0)
        goto LAB14;

LAB15:
LAB12:
LAB9:    t1 = (t0 + 6194);
    t11 = *((int *)t1);
    t2 = (t0 + 6198);
    t12 = *((int *)t2);
    if (t11 == t12)
        goto LAB10;

LAB19:    t13 = (t11 + -1);
    t11 = t13;
    t6 = (t0 + 6194);
    *((int *)t6) = t11;
    goto LAB7;

LAB11:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 1968U);
    t6 = *((char **)t1);
    t1 = (t0 + 6132U);
    t7 = (t0 + 1192U);
    t9 = *((char **)t7);
    t7 = (t0 + 6084U);
    t10 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t19, t6, t1, t9, t7);
    t20 = (t0 + 1968U);
    t21 = *((char **)t20);
    t20 = (t21 + 0);
    t22 = (t19 + 12U);
    t3 = *((unsigned int *)t22);
    t4 = (1U * t3);
    memcpy(t20, t10, t4);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t3 = (t13 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    *((unsigned char *)t1) = (unsigned char)3;
    goto LAB12;

LAB14:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1968U);
    t6 = *((char **)t1);
    t1 = (t0 + 6132U);
    t7 = (t0 + 1192U);
    t9 = *((char **)t7);
    t7 = (t0 + 6084U);
    t23 = ieee_p_3620187407_sub_4060537613_3965413181(IEEE_P_3620187407, t6, t1, t9, t7);
    if (t23 != 0)
        goto LAB16;

LAB18:
LAB17:    goto LAB12;

LAB16:    xsi_set_current_line(53, ng0);
    t10 = (t0 + 1968U);
    t20 = *((char **)t10);
    t10 = (t0 + 6132U);
    t21 = (t0 + 1192U);
    t22 = *((char **)t21);
    t21 = (t0 + 6084U);
    t24 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t19, t20, t10, t22, t21);
    t25 = (t0 + 1968U);
    t26 = *((char **)t25);
    t25 = (t26 + 0);
    t27 = (t19 + 12U);
    t3 = *((unsigned int *)t27);
    t4 = (1U * t3);
    memcpy(t25, t24, t4);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 2088U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t3 = (t13 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    *((unsigned char *)t1) = (unsigned char)3;
    goto LAB17;

}


extern void work_a_3926497698_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3926497698_3212880686_p_0};
	xsi_register_didat("work_a_3926497698_3212880686", "isim/tb_divider_isim_beh.exe.sim/work/a_3926497698_3212880686.didat");
	xsi_register_executes(pe);
}
